# Fisch Macro

An Android app that watches the Fisch reel minigame on your screen and holds or releases to keep the white bar on the fish. It only reads the screen and presses it. It does not touch the game's code or memory.

## How it works

- **Reads the screen** (Android screen capture, half resolution) and looks only at the strip you mark during calibration.
- **Measures the white bar's width every frame**, so any rod and any bar size works without presets.
- **Finds the fish** by the color you tap during calibration.
- **Steers**: holding pulls the bar right, letting go lets it fall left. A small PID controller turns the gap between fish and bar (plus how fast each is moving) into quick hold/release pulses.
- **Presses the screen** through an Android accessibility service.

Rods (Black Fairy, Noiseform, Olympian Godbreaker, Plaguereaver) only change how hard it steers. Small bars steer harder, big bars gentler.

## Build the APK from your phone (no computer)

1. On github.com make a new repository (private is fine).
2. **Add file > Upload files** and upload `FischMacro.zip` (leave it zipped).
3. **Add file > Create new file**, name it `.github/workflows/build.yml`, paste the contents of `build.yml`, commit.
4. **Actions** tab > "Build Fisch Macro APK" > **Run workflow**.
5. When it finishes (about 5 minutes), open the repo's **Releases** and download `FischMacro.apk`.

## Install on a Galaxy S24

- Samsung **Auto Blocker** blocks installing APKs: Settings > Security and privacy > Auto Blocker > turn off while installing.
- Open the downloaded APK and allow your browser/Files app to install apps.

## First-time setup

1. Open **Fisch Macro**. Turn on the accessibility service (Step 1). If the switch is greyed out: App info > three dots > **Allow restricted settings**, then try again.
2. Tap **Start screen capture** and accept.
3. Open Fisch (landscape). A small panel floats on top.
4. Cast and shake until the reel bar appears, then tap **Calibrate** on the panel and follow the four prompts:
   1. tap the white bar
   2. drag along the whole dark track, left end to right end
   3. tap the fish icon (or "Same color")
   4. tap a safe spot to press and hold (not a button)
5. Pick your rod with the **Rod** button, then press **Start** before a reel. Press **Stop** any time.

Calibrate again if you rotate the phone or change Roblox's UI size.

## Tuning

- The strip in the panel shows what the macro sees: white bar, blue dot for the fish. If the bar flickers, raise **Color tolerance** in the app. If it chases the fish too slowly, raise **Steering strength**.
- Fish and bar being the same color works much worse (the fish disappears when it's inside the bar). Tap carefully on the fish during calibration.

## Desktop test

`tools/SimTest.java` runs the detector and controller against a simulated reel. It tests the logic against a made-up physics model, not the real game.
