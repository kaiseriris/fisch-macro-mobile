package com.fischmacro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Display;

/**
 * Presses and holds the screen through the accessibility service.
 *
 * A hold is a chain of short touch segments that each continue the last one, so the finger stays
 * down. Letting go means the next segment is sent as the final one. Everything runs on the main thread.
 */
final class HoldInjector {
    private static final long SEG_MS = 25;

    private final AccessibilityService svc;
    private final Handler main = new Handler(Looper.getMainLooper());

    private volatile float fx = 0.62f, fy = 0.40f;
    private volatile boolean lastSent;

    // main-thread state
    private boolean want, down, pending, ending;
    private GestureDescription.StrokeDescription cur;
    private float px, py;

    HoldInjector(AccessibilityService svc) {
        this.svc = svc;
    }

    void setFraction(float x, float y) {
        fx = x;
        fy = y;
    }

    /** Safe to call from any thread, as often as you like. */
    void setHold(boolean hold) {
        if (hold == lastSent) return;
        lastSent = hold;
        main.post(() -> apply(hold));
    }

    private void apply(boolean h) {
        want = h;
        if (want && !down && !pending) startStroke();
    }

    private void startStroke() {
        DisplayManager dm = (DisplayManager) svc.getSystemService(android.content.Context.DISPLAY_SERVICE);
        Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics m = new DisplayMetrics();
        d.getRealMetrics(m);
        px = fx * m.widthPixels;
        py = fy * m.heightPixels;
        Path p = new Path();
        p.moveTo(px, py);
        cur = new GestureDescription.StrokeDescription(p, 0, SEG_MS, true);
        down = true;
        ending = false;
        send(cur);
    }

    private void send(GestureDescription.StrokeDescription s) {
        pending = true;
        boolean ok;
        try {
            GestureDescription g = new GestureDescription.Builder().addStroke(s).build();
            ok = svc.dispatchGesture(g, callback, main);
        } catch (RuntimeException e) {
            ok = false;
        }
        if (!ok) {
            pending = false;
            down = false;
            ending = false;
            cur = null;
            retryLater();
        }
    }

    private void retryLater() {
        if (!want) return;
        main.postDelayed(() -> {
            if (want && !down && !pending) startStroke();
        }, 40);
    }

    private final AccessibilityService.GestureResultCallback callback =
            new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gesture) {
                    pending = false;
                    if (ending) {
                        down = false;
                        ending = false;
                        cur = null;
                        if (want) startStroke();
                        return;
                    }
                    if (!down || cur == null) return;
                    Path p = new Path();
                    p.moveTo(px, py);
                    if (want) {
                        cur = cur.continueStroke(p, 0, SEG_MS, true);
                        send(cur);
                    } else {
                        cur = cur.continueStroke(p, 0, 1, false);
                        ending = true;
                        send(cur);
                    }
                }

                @Override
                public void onCancelled(GestureDescription gesture) {
                    pending = false;
                    down = false;
                    ending = false;
                    cur = null;
                    retryLater();
                }
            };
}
