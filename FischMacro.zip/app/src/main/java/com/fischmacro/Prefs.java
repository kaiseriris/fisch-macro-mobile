package com.fischmacro;

import android.content.Context;
import android.content.SharedPreferences;

/** Saved settings and calibration. */
public final class Prefs {

    /** Where the reel track is and what the bar and fish look like. Pixel values are in capture-frame pixels. */
    public static final class Calib {
        public int frameW, frameH;
        public int trackL, trackT, trackR, trackB;
        public int barRgb, fishRgb;
        /** Where to press and hold, as a fraction of the screen. */
        public float holdFx = 0.62f, holdFy = 0.40f;

        public boolean valid() {
            return frameW > 0 && frameH > 0 && trackR - trackL >= 40 && trackB - trackT >= 1;
        }
    }

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("fisch", Context.MODE_PRIVATE);
    }

    public static Calib loadCalib(Context c) {
        SharedPreferences p = sp(c);
        Calib k = new Calib();
        k.frameW = p.getInt("fw", 0);
        k.frameH = p.getInt("fh", 0);
        k.trackL = p.getInt("tl", 0);
        k.trackT = p.getInt("tt", 0);
        k.trackR = p.getInt("tr", 0);
        k.trackB = p.getInt("tb", 0);
        k.barRgb = p.getInt("bar", 0xF5F5F5);
        k.fishRgb = p.getInt("fish", 0x5AC8FF);
        k.holdFx = p.getFloat("hx", 0.62f);
        k.holdFy = p.getFloat("hy", 0.40f);
        return k;
    }

    public static void saveCalib(Context c, Calib k) {
        sp(c).edit()
                .putInt("fw", k.frameW).putInt("fh", k.frameH)
                .putInt("tl", k.trackL).putInt("tt", k.trackT)
                .putInt("tr", k.trackR).putInt("tb", k.trackB)
                .putInt("bar", k.barRgb).putInt("fish", k.fishRgb)
                .putFloat("hx", k.holdFx).putFloat("hy", k.holdFy)
                .apply();
    }

    public static int rod(Context c) { return sp(c).getInt("rod", 0); }
    public static void setRod(Context c, int i) { sp(c).edit().putInt("rod", i).apply(); }

    /** Steering sensitivity, 0.5 to 2.0. */
    public static float sens(Context c) { return sp(c).getFloat("sens", 1.0f); }
    public static void setSens(Context c, float v) { sp(c).edit().putFloat("sens", v).apply(); }

    /** Color tolerance, 40 to 110. */
    public static int tol(Context c) { return sp(c).getInt("tol", 70); }
    public static void setTol(Context c, int v) { sp(c).edit().putInt("tol", v).apply(); }
}
