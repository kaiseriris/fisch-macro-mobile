package com.fischmacro;

/**
 * Decides when to hold the screen so the white bar follows the fish.
 *
 * In Fisch, holding pulls the bar right and letting go lets it fall left. The controller works out
 * a "duty" (0..1, how much of the time to hold) from where the fish is relative to the bar and how
 * fast each is moving, then turns that into quick hold/release pulses (PWM). The integral term
 * learns the hold ratio that keeps the bar hovering in place.
 *
 * All distances are measured in bar-widths so one set of gains works for small and big bars.
 */
public final class Controller {

    private static final int MISS_LIMIT = 10;
    private static final int ARM_FRAMES = 3;

    private final RodProfile prof;
    /** User sensitivity multiplier, 0.5..2.0. */
    public double sens = 1.0;
    /** Starting hold ratio while hovering. The integral term adjusts it from there. */
    public double hover = 0.45;
    public int periodMs = 80;
    /** Base gains (bar-width units). Public so the desktop test can sweep them. */
    public double kpBase = 0.8, kiBase = 0.2, kdBase = 0.2;

    private boolean inited;
    private long lastT;
    private double pBar, pFish, vBar, vFish, integ;
    private int miss, good;
    private boolean active;
    private double duty;

    public Controller(RodProfile prof) {
        this.prof = prof;
    }

    public boolean isActive() { return active; }
    public double duty() { return duty; }

    public void reset() {
        inited = false;
        integ = 0;
        vBar = 0;
        vFish = 0;
        miss = 0;
        good = 0;
        active = false;
        duty = 0;
    }

    public void update(Detector.Result r, long tNs) {
        if (r == null || !r.ok()) {
            good = 0;
            if (++miss > MISS_LIMIT) reset();
            return;
        }
        miss = 0;
        double tw = r.trackW;
        double bw = Math.max(0.02, r.barWidth() / tw);
        double bc = r.barCenter() / tw;
        double fx = r.fishX / tw;

        if (!inited) {
            inited = true;
            pBar = bc;
            pFish = fx;
            lastT = tNs;
            vBar = 0;
            vFish = 0;
            good = 1;
            return;
        }
        double dt = (tNs - lastT) / 1e9;
        lastT = tNs;
        if (dt < 0.004) dt = 0.004;
        if (dt > 0.1) dt = 0.1;

        final double a = 0.45;
        vBar += a * ((bc - pBar) / dt - vBar);
        vFish += a * ((fx - pFish) / dt - vFish);
        pBar = bc;
        pFish = fx;

        if (++good >= ARM_FRAMES) active = true;
        if (!active) return;

        double k = prof.aggression * sens;
        double kp = kpBase * k;
        double ki = kiBase * k;
        double kd = kdBase * k;

        double e = (fx - bc) / bw;
        double ev = (vFish - vBar) / bw;
        integ += ki * e * dt;
        if (integ > 0.35) integ = 0.35;
        if (integ < -0.35) integ = -0.35;

        double d = hover + kp * e + integ + kd * ev;
        if (d < 0) d = 0;
        if (d > 1) d = 1;
        duty = d;
    }

    /** True if the screen should be held down at time tNs. */
    public boolean wantHold(long tNs) {
        if (!active) return false;
        if (duty >= 0.92) return true;
        if (duty <= 0.08) return false;
        double ms = tNs / 1e6;
        double phase = (ms % periodMs) / periodMs;
        return phase < duty;
    }
}
