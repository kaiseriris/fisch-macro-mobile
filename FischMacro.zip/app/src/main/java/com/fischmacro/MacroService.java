package com.fischmacro;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * The accessibility service does two jobs: it draws the small floating control panel, and it is the
 * thing that presses and holds the screen (that is what accessibility services are allowed to do).
 */
public class MacroService extends AccessibilityService {

    private WindowManager wm;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private float density = 1f;

    private LinearLayout panel;
    private LinearLayout body;
    private TextView statusTv;
    private ScopeView scope;
    private Button startBtn, rodBtn;
    private WindowManager.LayoutParams panelLp;

    private FrameLayout calibRoot;
    private HoldInjector injector;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Shared.macro = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        density = getResources().getDisplayMetrics().density;
        injector = new HoldInjector(this);
        applyHoldPoint(Prefs.loadCalib(this));
        buildPanel();
        ui.post(refresh);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() { setHold(false); }

    @Override
    public boolean onUnbind(Intent intent) {
        teardown();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }

    private void teardown() {
        Shared.running = false;
        Shared.macro = null;
        ui.removeCallbacksAndMessages(null);
        if (injector != null) injector.setHold(false);
        closeCalibration();
        if (panel != null && wm != null) {
            try { wm.removeView(panel); } catch (Throwable ignored) {}
            panel = null;
        }
    }

    /** Called from the capture thread. */
    void setHold(boolean hold) {
        HoldInjector inj = injector;
        if (inj != null) inj.setHold(hold);
    }

    private void applyHoldPoint(Prefs.Calib c) {
        if (injector != null) injector.setFraction(c.holdFx, c.holdFy);
    }

    // ---- panel -------------------------------------------------------------------------------

    private int dp(int v) {
        return Math.round(v * density);
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), dp(6), dp(12), dp(6));
        return b;
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), dp(6), dp(8), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xCC10161C);
        bg.setCornerRadius(dp(12));
        panel.setBackground(bg);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Fisch Macro  (drag me)");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(12);
        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button collapse = smallButton("-");
        header.addView(collapse);
        panel.addView(header);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        panel.addView(body);

        statusTv = new TextView(this);
        statusTv.setTextColor(0xFFB0BEC5);
        statusTv.setTextSize(12);
        body.addView(statusTv);

        scope = new ScopeView(this, density);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(230), dp(22));
        slp.topMargin = dp(4);
        slp.bottomMargin = dp(4);
        body.addView(scope, slp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        startBtn = smallButton("Start");
        Button calBtn = smallButton("Calibrate");
        rodBtn = smallButton("Rod");
        row.addView(startBtn);
        row.addView(calBtn);
        row.addView(rodBtn);
        body.addView(row);

        startBtn.setOnClickListener(v -> toggleRun());
        calBtn.setOnClickListener(v -> startCalibration());
        rodBtn.setOnClickListener(v -> {
            int next = (Prefs.rod(this) + 1) % RodProfile.ALL.length;
            Prefs.setRod(this, next);
            if (Shared.running && Shared.capture != null) {
                Shared.capture.configure(next, Prefs.sens(this), Prefs.tol(this));
            }
        });
        collapse.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            collapse.setText(show ? "-" : "+");
        });

        panelLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(12);
        panelLp.y = dp(12);

        title.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        ox = panelLp.x;
                        oy = panelLp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = ox + Math.round(e.getRawX() - sx);
                        panelLp.y = oy + Math.round(e.getRawY() - sy);
                        try { wm.updateViewLayout(panel, panelLp); } catch (Throwable ignored) {}
                        return true;
                    default:
                        return true;
                }
            }
        });

        wm.addView(panel, panelLp);
    }

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            if (panel == null) return;
            String s;
            if (Shared.capture == null) s = "Screen capture is off (open the app)";
            else if (!Shared.running) s = "Stopped";
            else s = Shared.status;
            statusTv.setText(s);
            startBtn.setText(Shared.running ? "Stop" : "Start");
            RodProfile rp = RodProfile.byIndex(Prefs.rod(MacroService.this));
            rodBtn.setText(rp.name);
            scope.invalidate();
            ui.postDelayed(this, 100);
        }
    };

    private void toggleRun() {
        if (Shared.running) {
            Shared.running = false;
            return;
        }
        CaptureService cs = Shared.capture;
        if (cs == null) {
            toast("Start screen capture in the Fisch Macro app first.");
            openApp();
            return;
        }
        Prefs.Calib c = Prefs.loadCalib(this);
        if (!c.valid()) {
            toast("Calibrate first: tap Calibrate while the reel bar is on screen.");
            return;
        }
        applyHoldPoint(c);
        cs.configure(Prefs.rod(this), Prefs.sens(this), Prefs.tol(this));
        Shared.running = true;
    }

    private void openApp() {
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable ignored) {}
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ---- calibration ---------------------------------------------------------------------------

    private void startCalibration() {
        CaptureService cs = Shared.capture;
        if (cs == null) {
            toast("Start screen capture in the Fisch Macro app first.");
            openApp();
            return;
        }
        Shared.running = false;
        toast("Grabbing the screen...");
        // The screenshot arrives with the next frame the screen produces (immediately in a live game).
        cs.requestSnapshot((bmp, fw, fh) -> ui.post(() -> showCalibration(bmp)));
    }

    private void showCalibration(Bitmap bmp) {
        closeCalibration();
        calibRoot = new FrameLayout(this);
        CalibrationView cv = new CalibrationView(this, bmp, new CalibrationView.Listener() {
            @Override
            public void onDone(Prefs.Calib c) {
                Prefs.saveCalib(MacroService.this, c);
                applyHoldPoint(c);
                closeCalibration();
                toast("Saved. Press Start when the next reel appears.");
            }

            @Override
            public void onCancel() {
                closeCalibration();
            }
        });
        calibRoot.addView(cv, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE);
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        wm.addView(calibRoot, lp);
        if (panel != null) panel.setVisibility(View.GONE);
    }

    private void closeCalibration() {
        if (calibRoot != null && wm != null) {
            try { wm.removeView(calibRoot); } catch (Throwable ignored) {}
            calibRoot = null;
        }
        if (panel != null) panel.setVisibility(View.VISIBLE);
    }

    // ---- live view of what the macro sees ------------------------------------------------------

    /** Tiny strip showing the bar (white) and fish (blue) the macro currently sees. */
    private static final class ScopeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final float d;

        ScopeView(android.content.Context c, float density) {
            super(c);
            d = density;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF263238);
            r.set(0, 0, w, h);
            c.drawRoundRect(r, 4 * d, 4 * d, p);
            float bl = Shared.scopeBarL, br = Shared.scopeBarR, f = Shared.scopeFish;
            if (bl >= 0 && br > bl) {
                p.setColor(Shared.scopeActive ? 0xFFFFFFFF : 0xFF90A4AE);
                r.set(bl * w, 2 * d, br * w, h - 2 * d);
                c.drawRoundRect(r, 3 * d, 3 * d, p);
            }
            if (f >= 0) {
                p.setColor(0xFF29B6F6);
                c.drawCircle(f * w, h / 2, 5 * d, p);
            }
        }
    }
}
