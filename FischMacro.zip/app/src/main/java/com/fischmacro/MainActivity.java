package com.fischmacro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

/** Setup screen: turn on the two permissions, pick a rod, then switch to the game. */
public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 41;
    private static final int REQ_NOTIF = 42;

    private TextView statusTv;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private float density;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        density = getResources().getDisplayMetrics().density;
        buildUi();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private int dp(int v) {
        return Math.round(v * density);
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        t.setLayoutParams(lp);
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setOnClickListener(l);
        return btn;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(28));
        sv.addView(root);

        root.addView(text("Fisch Macro", 24, true));
        root.addView(text("Watches the reel bar on your screen and holds or releases to keep the white bar on the fish. "
                + "It only reads the screen and presses it, like a player would.", 14, false));

        statusTv = text("", 14, true);
        root.addView(statusTv);

        root.addView(text("Step 1: Accessibility", 16, true));
        root.addView(text("Turn on Fisch Macro under Installed apps. If the switch is greyed out, open App info, "
                + "tap the three dots, and choose Allow restricted settings first.", 13, false));
        root.addView(button("Open Accessibility settings", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("Open App info (for Allow restricted settings)", v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));

        root.addView(text("Step 2: Screen capture", 16, true));
        root.addView(text("Lets the app read the reel bar. Android asks you to confirm. Pick \"Entire screen\" if asked.", 13, false));
        root.addView(button("Start screen capture", v -> {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
        }));
        root.addView(button("Stop screen capture", v -> {
            startService(new Intent(this, CaptureService.class).setAction(CaptureService.ACTION_STOP));
            ui.postDelayed(this::refreshStatus, 400);
        }));

        root.addView(text("Step 3: Pick your rod", 16, true));
        Spinner rod = new Spinner(this);
        String[] names = new String[RodProfile.ALL.length];
        for (int i = 0; i < names.length; i++) {
            RodProfile r = RodProfile.ALL[i];
            names[i] = r.name + "  (Control " + r.control + ")";
        }
        rod.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        rod.setSelection(Prefs.rod(this));
        rod.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                Prefs.setRod(MainActivity.this, pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {}
        });
        root.addView(rod);

        final TextView sensLabel = text("", 13, false);
        root.addView(sensLabel);
        SeekBar sens = new SeekBar(this);
        sens.setMax(150);
        sens.setProgress(Math.round((Prefs.sens(this) - 0.5f) * 100));
        sensLabel.setText("Steering strength: " + String.format("%.2f", Prefs.sens(this)));
        sens.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                float v = 0.5f + p / 100f;
                Prefs.setSens(MainActivity.this, v);
                sensLabel.setText("Steering strength: " + String.format("%.2f", v));
            }
        });
        root.addView(sens);

        final TextView tolLabel = text("", 13, false);
        root.addView(tolLabel);
        SeekBar tol = new SeekBar(this);
        tol.setMax(70);
        tol.setProgress(Prefs.tol(this) - 40);
        tolLabel.setText("Color tolerance: " + Prefs.tol(this) + "  (raise it if the bar flickers in the panel's strip)");
        tol.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                Prefs.setTol(MainActivity.this, 40 + p);
                tolLabel.setText("Color tolerance: " + (40 + p) + "  (raise it if the bar flickers in the panel's strip)");
            }
        });
        root.addView(tol);

        root.addView(text("Step 4: In Fisch", 16, true));
        root.addView(text("Open Fisch. A small Fisch Macro panel floats on top. Cast, shake, and when the reel bar "
                + "appears tap Calibrate and follow the 4 prompts (once per phone orientation). "
                + "After that, press Start before a reel and Stop when you're done.", 13, false));

        setContentView(sv);
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar s) {}
        @Override public void onStopTrackingTouch(SeekBar s) {}
    }

    private void refreshStatus() {
        boolean acc = Shared.macro != null;
        boolean cap = Shared.capture != null;
        statusTv.setText("Accessibility: " + (acc ? "ON" : "off") + "\nScreen capture: " + (cap ? "ON" : "off"));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent svc = new Intent(this, CaptureService.class);
            svc.putExtra(CaptureService.EXTRA_CODE, resultCode);
            svc.putExtra(CaptureService.EXTRA_DATA, data);
            startForegroundService(svc);
            ui.postDelayed(this::refreshStatus, 800);
        }
    }
}
