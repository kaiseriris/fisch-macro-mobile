package com.fischmacro;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.Arrays;

/**
 * Full-screen overlay showing a frozen screenshot of the game. Four taps teach the app everything
 * it needs, so no colors or positions are hard-coded:
 *   1. tap the white bar          (learns the bar color and how tall the track is)
 *   2. drag along the whole track (learns left and right ends)
 *   3. tap the fish icon          (learns the fish color)
 *   4. tap a safe spot to hold    (where the macro will press and hold)
 */
final class CalibrationView extends View {

    interface Listener {
        void onDone(Prefs.Calib c);
        void onCancel();
    }

    private final Bitmap bmp;
    private final Listener listener;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;

    private int step; // 0 bar, 1 track, 2 fish, 3 hold
    private int barRgb, fishRgb;
    private int rowTop, rowBottom; // frame px
    private float barTapX, barTapY, fishTapX, fishTapY, holdX, holdY;
    private float dragX0, dragX1, dragY;
    private boolean dragging, haveTrack;
    private int trackL, trackR;

    private final RectF cancelRect = new RectF();
    private final RectF sameRect = new RectF();
    private int downOn; // 0 none, 1 cancel, 2 same

    CalibrationView(Context ctx, Bitmap bmp, Listener l) {
        super(ctx);
        this.bmp = bmp;
        this.listener = l;
        this.dp = ctx.getResources().getDisplayMetrics().density;
    }

    private String prompt() {
        switch (step) {
            case 0: return "1/4  Tap the WHITE BAR";
            case 1: return "2/4  Drag along the whole track, left end to right end";
            case 2: return "3/4  Tap the FISH icon";
            default: return "4/4  Tap a safe spot to press and hold (not a button)";
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.BLACK);
        c.drawRect(0, 0, w, h, paint);
        c.drawBitmap(bmp, null, new RectF(0, 0, w, h), null);

        // markers
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2 * dp);
        if (step > 0) {
            paint.setColor(0xFFFFEB3B);
            c.drawCircle(barTapX, barTapY, 8 * dp, paint);
        }
        if (dragging || haveTrack) {
            paint.setColor(0xFF00E5FF);
            float x0 = Math.min(dragX0, dragX1), x1 = Math.max(dragX0, dragX1);
            float y = dragging ? dragY : (rowTop + rowBottom) * 0.5f * h / bmp.getHeight();
            float half = haveTrack ? Math.max(2 * dp, (rowBottom - rowTop) * 0.5f * h / bmp.getHeight()) : 4 * dp;
            c.drawRect(x0, y - half, x1, y + half, paint);
        }
        if (step > 2) {
            paint.setColor(0xFFFF4081);
            c.drawCircle(fishTapX, fishTapY, 8 * dp, paint);
        }

        // top band with instructions and buttons
        float band = 64 * dp;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xDD000000);
        c.drawRect(0, 0, w, band, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(16 * dp);
        c.drawText(prompt(), 16 * dp, 38 * dp, paint);

        float bw = 96 * dp, bh = 40 * dp, top = 12 * dp;
        cancelRect.set(w - bw - 12 * dp, top, w - 12 * dp, top + bh);
        drawButton(c, cancelRect, "Cancel");
        if (step == 2) {
            sameRect.set(cancelRect.left - 150 * dp - 12 * dp, top, cancelRect.left - 12 * dp, top + bh);
            drawButton(c, sameRect, "Same color");
        } else {
            sameRect.setEmpty();
        }
    }

    private void drawButton(Canvas c, RectF r, String label) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF37474F);
        c.drawRoundRect(r, 8 * dp, 8 * dp, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(14 * dp);
        float tw = paint.measureText(label);
        c.drawText(label, r.centerX() - tw / 2, r.centerY() + 5 * dp, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downOn = cancelRect.contains(x, y) ? 1 : (sameRect.contains(x, y) ? 2 : 0);
                if (downOn == 0 && step == 1) {
                    dragging = true;
                    dragX0 = x;
                    dragX1 = x;
                    dragY = y;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) {
                    dragX1 = x;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (downOn == 1) {
                    if (cancelRect.contains(x, y)) listener.onCancel();
                    downOn = 0;
                    return true;
                }
                if (downOn == 2) {
                    if (sameRect.contains(x, y)) {
                        fishRgb = barRgb;
                        fishTapX = barTapX;
                        fishTapY = barTapY;
                        step = 3;
                        invalidate();
                    }
                    downOn = 0;
                    return true;
                }
                if (step == 1 && dragging) dragX1 = x;
                handleTap(x, y);
                return true;
            default:
                return true;
        }
    }

    private void handleTap(float x, float y) {
        int bw = bmp.getWidth(), bh = bmp.getHeight();
        int fx = clamp(Math.round(x * bw / getWidth()), 0, bw - 1);
        int fy = clamp(Math.round(y * bh / getHeight()), 0, bh - 1);
        if (y < 64 * dp && step != 1) return; // ignore taps on the instruction band
        switch (step) {
            case 0: {
                barRgb = medianColor(fx, fy, 3);
                // walk up and down while the pixels still look like the bar to find the track height
                int top = fy, bottom = fy;
                while (top > 0 && fy - top < 200 && dist(bmp.getPixel(fx, top - 1), barRgb) <= 70) top--;
                while (bottom < bh - 1 && bottom - fy < 200 && dist(bmp.getPixel(fx, bottom + 1), barRgb) <= 70) bottom++;
                rowTop = top;
                rowBottom = bottom;
                barTapX = x;
                barTapY = y;
                step = 1;
                break;
            }
            case 1: {
                dragging = false;
                if (Math.abs(dragX1 - dragX0) < 60 * dp) {
                    dragX0 = dragX1 = 0;
                    break; // too short, try again
                }
                float l = Math.min(dragX0, dragX1), r = Math.max(dragX0, dragX1);
                trackL = clamp(Math.round(l * bw / getWidth()), 0, bw - 1);
                trackR = clamp(Math.round(r * bw / getWidth()), 1, bw);
                haveTrack = true;
                step = 2;
                break;
            }
            case 2: {
                fishTapX = x;
                fishTapY = y;
                fishRgb = pickFishColor(fx, fy);
                step = 3;
                break;
            }
            default: {
                holdX = x;
                holdY = y;
                finish();
                return;
            }
        }
        invalidate();
    }

    private void finish() {
        Prefs.Calib k = new Prefs.Calib();
        k.frameW = bmp.getWidth();
        k.frameH = bmp.getHeight();
        k.trackL = trackL;
        k.trackR = trackR;
        k.trackT = rowTop;
        k.trackB = rowBottom;
        k.barRgb = barRgb;
        k.fishRgb = fishRgb;
        k.holdFx = holdX / getWidth();
        k.holdFy = holdY / getHeight();
        listener.onDone(k);
    }

    /** The fish is small and hard to tap exactly, so look around the tap for pixels unlike the track and the bar. */
    private int pickFishColor(int cx, int cy) {
        int trackBg = medianColor(clamp(trackL + 6, 0, bmp.getWidth() - 1), (rowTop + rowBottom) / 2, 2);
        int r = 12;
        long sr = 0, sg = 0, sb = 0;
        int n = 0;
        for (int yy = Math.max(0, cy - r); yy <= Math.min(bmp.getHeight() - 1, cy + r); yy++) {
            for (int xx = Math.max(0, cx - r); xx <= Math.min(bmp.getWidth() - 1, cx + r); xx++) {
                int p = bmp.getPixel(xx, yy);
                if (dist(p, trackBg) > 60 && dist(p, barRgb) > 50) {
                    sr += (p >> 16) & 255;
                    sg += (p >> 8) & 255;
                    sb += p & 255;
                    n++;
                }
            }
        }
        if (n < 4) return bmp.getPixel(cx, cy) & 0xFFFFFF;
        return (int) (sr / n) << 16 | (int) (sg / n) << 8 | (int) (sb / n);
    }

    private int medianColor(int cx, int cy, int radius) {
        int cnt = 0;
        int[] rs = new int[(2 * radius + 1) * (2 * radius + 1)];
        int[] gs = new int[rs.length];
        int[] bs = new int[rs.length];
        for (int yy = cy - radius; yy <= cy + radius; yy++) {
            for (int xx = cx - radius; xx <= cx + radius; xx++) {
                if (xx < 0 || yy < 0 || xx >= bmp.getWidth() || yy >= bmp.getHeight()) continue;
                int p = bmp.getPixel(xx, yy);
                rs[cnt] = (p >> 16) & 255;
                gs[cnt] = (p >> 8) & 255;
                bs[cnt] = p & 255;
                cnt++;
            }
        }
        if (cnt == 0) return 0xF5F5F5;
        Arrays.sort(rs, 0, cnt);
        Arrays.sort(gs, 0, cnt);
        Arrays.sort(bs, 0, cnt);
        return (rs[cnt / 2] << 16) | (gs[cnt / 2] << 8) | bs[cnt / 2];
    }

    private static int dist(int a, int b) {
        int dr = ((a >> 16) & 255) - ((b >> 16) & 255);
        int dg = ((a >> 8) & 255) - ((b >> 8) & 255);
        int db = (a & 255) - (b & 255);
        return (int) Math.sqrt(dr * dr + dg * dg + db * db);
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
