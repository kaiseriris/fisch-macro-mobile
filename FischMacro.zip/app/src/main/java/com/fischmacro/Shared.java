package com.fischmacro;

/** Small bag of live state shared between the capture service, the accessibility service and the UI. */
final class Shared {
    static volatile boolean running;
    static volatile CaptureService capture;
    static volatile MacroService macro;

    static volatile String status = "Idle";
    /** Detected bar and fish, as 0..1 fractions of the track. -1 when not seen. */
    static volatile float scopeBarL = -1, scopeBarR = -1, scopeFish = -1;
    static volatile float scopeDuty;
    static volatile boolean scopeActive;

    private Shared() {}
}
