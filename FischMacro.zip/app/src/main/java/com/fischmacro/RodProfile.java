package com.fischmacro;

/**
 * Starting tunings per rod. The bar's size is always measured live from the screen, so these only
 * decide how aggressively the macro steers. Control values come from the community wikis and some
 * sources disagree, so treat them as a rough guide, not exact numbers.
 */
public final class RodProfile {
    public final String name;
    public final String control;
    /** 1.0 = normal. Higher = steers harder (small bars), lower = relaxed (big bars). */
    public final double aggression;
    public final String note;

    private RodProfile(String name, String control, double aggression, String note) {
        this.name = name;
        this.control = control;
        this.aggression = aggression;
        this.note = note;
    }

    public static final RodProfile[] ALL = new RodProfile[] {
        new RodProfile("Black Fairy Rod", "0.18", 1.0, "Medium bar."),
        new RodProfile("Noiseform", "0", 1.25, "Smallest bar of the four, so it steers hardest."),
        new RodProfile("Olympian Godbreaker", "0.18", 1.0, "Medium bar."),
        new RodProfile("Plaguereaver", "0.4", 0.8, "Biggest bar, so it steers gently."),
    };

    public static RodProfile byIndex(int i) {
        if (i < 0 || i >= ALL.length) return ALL[0];
        return ALL[i];
    }
}
