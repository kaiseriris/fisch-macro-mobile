package com.fischmacro;

import java.util.Arrays;

/**
 * Reads one frame of the reel track and works out where the white bar and the fish are.
 *
 * Pure Java (no Android classes) so it can be tested on a desktop.
 *
 * Input is a strip of pixels cut out of the screen, exactly the region the user boxed in during
 * calibration. Colors for the bar and the fish come from calibration too, so nothing here depends
 * on guessing the game's exact shades.
 */
public final class Detector {

    public static final class Result {
        public boolean barFound;
        public boolean fishFound;
        /** True when the fish could not be told apart and is assumed to be inside the bar. */
        public boolean fishAssumed;
        public double barL, barR, fishX, trackW;

        public double barCenter() { return (barL + barR) * 0.5; }
        public double barWidth() { return barR - barL; }
        public boolean ok() { return barFound && fishFound; }
    }

    private int[] barHits = new int[0];
    private int[] fishHits = new int[0];
    private final int[] runS = new int[24];
    private final int[] runE = new int[24];

    /**
     * @param px     strip pixels, row-major, 0xRRGGBB (alpha ignored), length >= w*h
     * @param w      strip width in pixels (this is the track width)
     * @param h      strip height in rows
     * @param barRgb calibrated color of the white bar
     * @param fishRgb calibrated color of the fish icon
     * @param tol    color tolerance (RGB distance), about 40..110
     */
    public Result detect(int[] px, int w, int h, int barRgb, int fishRgb, int tol, Result out) {
        if (out == null) out = new Result();
        out.barFound = false;
        out.fishFound = false;
        out.fishAssumed = false;
        out.trackW = w;
        if (w < 20 || h < 1) return out;

        if (barHits.length != w) {
            barHits = new int[w];
            fishHits = new int[w];
        } else {
            Arrays.fill(barHits, 0);
            Arrays.fill(fishHits, 0);
        }

        final int br = (barRgb >> 16) & 255, bg = (barRgb >> 8) & 255, bb = barRgb & 255;
        final int fr = (fishRgb >> 16) & 255, fg = (fishRgb >> 8) & 255, fb = fishRgb & 255;
        final int tol2 = tol * tol;
        final int cdr = br - fr, cdg = bg - fg, cdb = bb - fb;
        final boolean similar = (cdr * cdr + cdg * cdg + cdb * cdb) < 40 * 40;

        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int p = px[row + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                int dbr = r - br, dbg = g - bg, dbb = b - bb;
                int db2 = dbr * dbr + dbg * dbg + dbb * dbb;
                if (similar) {
                    if (db2 <= tol2) barHits[x]++;
                } else {
                    int dfr = r - fr, dfg = g - fg, dfb = b - fb;
                    int df2 = dfr * dfr + dfg * dfg + dfb * dfb;
                    // each pixel goes to whichever calibrated color it is closer to
                    if (db2 <= df2) {
                        if (db2 <= tol2) barHits[x]++;
                    } else {
                        if (df2 <= tol2) fishHits[x]++;
                    }
                }
            }
        }

        final int minBarRows = Math.max(1, (int) Math.ceil(h * 0.5));
        // When the fish is a different color it can sit on top of the bar and cut a hole in it,
        // so bridge small gaps. When the colors match, keep runs apart so the fish stays separate.
        final int gapMax = similar ? Math.max(1, (int) (w * 0.008)) : Math.max(3, (int) (w * 0.07));

        int runs = 0;
        int curS = -1, lastOn = -1;
        for (int x = 0; x < w; x++) {
            boolean on = barHits[x] >= minBarRows;
            if (on) {
                if (curS < 0) curS = x;
                lastOn = x;
            } else if (curS >= 0 && x - lastOn > gapMax) {
                if (runs < runS.length) { runS[runs] = curS; runE[runs] = lastOn; runs++; }
                curS = -1;
            }
        }
        if (curS >= 0 && runs < runS.length) { runS[runs] = curS; runE[runs] = lastOn; runs++; }

        int best = -1, bestLen = 0;
        for (int i = 0; i < runs; i++) {
            int len = runE[i] - runS[i] + 1;
            if (len > bestLen) { bestLen = len; best = i; }
        }
        if (best < 0 || bestLen < w * 0.03 || bestLen > w * 0.92) return out;

        out.barFound = true;
        out.barL = runS[best];
        out.barR = runE[best] + 1;

        if (similar) {
            int fishRun = -1, fishLen = 0;
            for (int i = 0; i < runs; i++) {
                if (i == best) continue;
                int len = runE[i] - runS[i] + 1;
                if (len <= w * 0.2 && len > fishLen) { fishLen = len; fishRun = i; }
            }
            if (fishRun >= 0) {
                out.fishFound = true;
                out.fishX = (runS[fishRun] + runE[fishRun] + 1) * 0.5;
            } else {
                out.fishFound = true;
                out.fishAssumed = true;
                out.fishX = out.barCenter();
            }
            return out;
        }

        final int minFishRows = Math.max(1, (int) Math.ceil(h * 0.15));
        final int fishGap = Math.max(2, (int) (w * 0.01));
        long bestSum = 0;
        double bestCx = -1;
        int cs = -1, cLast = -1;
        long sum = 0;
        double wx = 0;
        for (int x = 0; x <= w; x++) {
            boolean on = x < w && fishHits[x] >= minFishRows;
            if (on) {
                if (cs < 0) { cs = x; sum = 0; wx = 0; }
                cLast = x;
                sum += fishHits[x];
                wx += (double) x * fishHits[x];
            } else if (cs >= 0 && (x >= w || x - cLast > fishGap)) {
                int width = cLast - cs + 1;
                if (width <= w * 0.2 && sum > bestSum) {
                    bestSum = sum;
                    bestCx = wx / sum + 0.5;
                }
                cs = -1;
            }
        }
        if (bestCx >= 0) {
            out.fishFound = true;
            out.fishX = bestCx;
        }
        return out;
    }
}
