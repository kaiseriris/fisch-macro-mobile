package com.fischmacro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Display;

import java.nio.ByteBuffer;

/**
 * Keeps a low-resolution copy of the screen coming in, reads the reel strip from every frame, and
 * runs the detector and controller on it. Needs the one-time "start recording" permission.
 */
public class CaptureService extends Service {

    static final String EXTRA_CODE = "code";
    static final String EXTRA_DATA = "data";
    static final String ACTION_STOP = "com.fischmacro.STOP";

    private static final String CHANNEL = "capture";
    private static final int NOTIF_ID = 7;
    /** Capture at half resolution: plenty for a thick reel bar and much lighter on the phone. */
    private static final float SCALE = 0.5f;
    private static final long STALE_NS = 250_000_000L;
    private static final long MAX_HOLD_NS = 6_000_000_000L;

    interface SnapshotCallback {
        void onSnapshot(Bitmap bmp, int frameW, int frameH);
    }

    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private DisplayManager dm;
    private DisplayManager.DisplayListener displayListener;
    private int frameW, frameH, dpi;
    private boolean stopped;

    private final Detector detector = new Detector();
    private final Detector.Result res = new Detector.Result();
    private Controller ctl = new Controller(RodProfile.byIndex(0));
    private int[] strip = new int[0];
    private Prefs.Calib calib;
    private int tol = 70;

    private volatile SnapshotCallback pendingSnap;
    private long lastGoodNs;
    private long holdSinceNs;
    private boolean lastHold;

    @Override
    public void onCreate() {
        super.onCreate();
        Shared.capture = this;
        calib = Prefs.loadCalib(this);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (projection != null) return START_NOT_STICKY;

        createChannel();
        startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);

        int code = intent == null ? 0 : intent.getIntExtra(EXTRA_CODE, 0);
        @SuppressWarnings("deprecation")
        Intent data = intent == null ? null : (Intent) intent.getParcelableExtra(EXTRA_DATA);
        if (data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        thread = new HandlerThread("fisch-capture");
        thread.start();
        handler = new Handler(thread.getLooper());
        dm = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        if (projection == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, handler);

        buildDisplay();

        displayListener = new DisplayManager.DisplayListener() {
            @Override public void onDisplayAdded(int displayId) {}
            @Override public void onDisplayRemoved(int displayId) {}
            @Override
            public void onDisplayChanged(int displayId) {
                if (displayId == Display.DEFAULT_DISPLAY) rebuildIfNeeded();
            }
        };
        dm.registerDisplayListener(displayListener, handler);
        handler.post(tick);
        Shared.status = "Capture on";
        return START_NOT_STICKY;
    }

    // ---- display / frames -------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    private void realSize(int[] out) {
        Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics m = new DisplayMetrics();
        d.getRealMetrics(m);
        out[0] = m.widthPixels;
        out[1] = m.heightPixels;
        out[2] = m.densityDpi;
    }

    private void buildDisplay() {
        int[] s = new int[3];
        realSize(s);
        frameW = Math.max(64, Math.round(s[0] * SCALE));
        frameH = Math.max(64, Math.round(s[1] * SCALE));
        dpi = s[2];
        reader = ImageReader.newInstance(frameW, frameH, PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(this::onImage, handler);
        vd = projection.createVirtualDisplay("fisch-macro", frameW, frameH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
    }

    /** Phone was rotated: resize the same virtual display (Android only allows one per permission). */
    private void rebuildIfNeeded() {
        if (stopped || vd == null) return;
        int[] s = new int[3];
        realSize(s);
        int nw = Math.max(64, Math.round(s[0] * SCALE));
        int nh = Math.max(64, Math.round(s[1] * SCALE));
        if (nw == frameW && nh == frameH) return;
        ImageReader old = reader;
        ImageReader nr = ImageReader.newInstance(nw, nh, PixelFormat.RGBA_8888, 2);
        nr.setOnImageAvailableListener(this::onImage, handler);
        vd.resize(nw, nh, s[2]);
        vd.setSurface(nr.getSurface());
        reader = nr;
        frameW = nw;
        frameH = nh;
        dpi = s[2];
        if (old != null) old.close();
    }

    private void onImage(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            handleFrame(img);
        } catch (Throwable t) {
            Shared.status = "Capture error";
        } finally {
            if (img != null) img.close();
        }
    }

    private void handleFrame(Image img) {
        Image.Plane plane = img.getPlanes()[0];
        ByteBuffer buf = plane.getBuffer();
        int rs = plane.getRowStride();
        int ps = plane.getPixelStride();
        int fw = img.getWidth();
        int fh = img.getHeight();

        SnapshotCallback sc = pendingSnap;
        if (sc != null) {
            pendingSnap = null;
            Bitmap full = Bitmap.createBitmap(rs / ps, fh, Bitmap.Config.ARGB_8888);
            buf.rewind();
            full.copyPixelsFromBuffer(buf);
            Bitmap out = (rs / ps == fw) ? full : Bitmap.createBitmap(full, 0, 0, fw, fh);
            sc.onSnapshot(out, fw, fh);
        }

        if (!Shared.running) return;

        Prefs.Calib c = calib;
        if (c == null || !c.valid()) {
            Shared.status = "Not calibrated";
            return;
        }
        float sx = (float) fw / c.frameW;
        float sy = (float) fh / c.frameH;
        if (Math.abs(sx - sy) > 0.03f) {
            Shared.status = "Screen rotated: recalibrate";
            return;
        }
        int tl = Math.max(0, Math.round(c.trackL * sx));
        int tr = Math.min(fw, Math.round(c.trackR * sx));
        int tt = Math.max(0, Math.round(c.trackT * sy));
        int tb = Math.min(fh - 1, Math.round(c.trackB * sy));
        int tw = tr - tl;
        if (tw < 20 || tb < tt) return;

        // sample a few rows through the middle of the track
        int span = tb - tt;
        int y0 = tt + Math.round(span * 0.2f);
        int y1 = tb - Math.round(span * 0.2f);
        if (y1 < y0) { y0 = tt; y1 = tb; }
        int rows = Math.max(1, Math.min(8, y1 - y0 + 1));
        if (strip.length < rows * tw) strip = new int[rows * tw];
        for (int i = 0; i < rows; i++) {
            int y = rows == 1 ? (y0 + y1) / 2 : y0 + (y1 - y0) * i / (rows - 1);
            int rowBase = y * rs;
            int o = i * tw;
            for (int x = 0; x < tw; x++) {
                int p = rowBase + (tl + x) * ps;
                int rr = buf.get(p) & 255;
                int gg = buf.get(p + 1) & 255;
                int bb = buf.get(p + 2) & 255;
                strip[o + x] = (rr << 16) | (gg << 8) | bb;
            }
        }

        long now = System.nanoTime();
        detector.detect(strip, tw, rows, c.barRgb, c.fishRgb, tol, res);
        ctl.update(res, now);
        if (res.ok()) lastGoodNs = now;

        Shared.scopeBarL = res.barFound ? (float) (res.barL / tw) : -1f;
        Shared.scopeBarR = res.barFound ? (float) (res.barR / tw) : -1f;
        Shared.scopeFish = res.fishFound ? (float) (res.fishX / tw) : -1f;
        Shared.scopeActive = ctl.isActive();
        Shared.scopeDuty = (float) ctl.duty();
        Shared.status = ctl.isActive() ? "Reeling" : (res.barFound ? "Bar seen..." : "Waiting for the reel");
    }

    /** Runs every 10 ms: turns the controller's duty into hold / release. */
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (stopped) return;
            long now = System.nanoTime();
            boolean want = Shared.running && (now - lastGoodNs) < STALE_NS && ctl.wantHold(now);
            if (want) {
                if (!lastHold) holdSinceNs = now;
                if (now - holdSinceNs > MAX_HOLD_NS) {
                    want = false; // safety: never stay pressed for more than a few seconds straight
                }
            }
            lastHold = want;
            MacroService m = Shared.macro;
            if (m != null) m.setHold(want);
            handler.postDelayed(this, 10);
        }
    };

    // ---- called by the overlay --------------------------------------------------------------

    /** Applies the chosen rod, sensitivity and color tolerance, and reloads calibration. */
    void configure(int rodIndex, float sens, int colorTol) {
        Handler h = handler;
        if (h == null) return;
        h.post(() -> {
            Controller c = new Controller(RodProfile.byIndex(rodIndex));
            c.sens = sens;
            ctl = c;
            tol = colorTol;
            calib = Prefs.loadCalib(CaptureService.this);
            lastGoodNs = 0;
        });
    }

    void requestSnapshot(SnapshotCallback cb) {
        pendingSnap = cb;
    }

    // ---- lifecycle ---------------------------------------------------------------------------

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Screen capture", NotificationManager.IMPORTANCE_LOW);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(ch);
    }

    @SuppressWarnings("deprecation")
    private Notification buildNotification() {
        Intent stop = new Intent(this, CaptureService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent openPi = PendingIntent.getActivity(this, 1, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Fisch Macro")
                .setContentText("Screen capture is on. Tap to open.")
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_delete, "Stop", stopPi)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        stopped = true;
        Shared.running = false;
        Shared.capture = null;
        Shared.status = "Capture off";
        MacroService m = Shared.macro;
        if (m != null) m.setHold(false);
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (dm != null && displayListener != null) dm.unregisterDisplayListener(displayListener);
        try { if (vd != null) vd.release(); } catch (Throwable ignored) {}
        try { if (reader != null) reader.close(); } catch (Throwable ignored) {}
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) {}
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }
}
