import com.fischmacro.Controller;
import com.fischmacro.Detector;
import com.fischmacro.RodProfile;

import java.util.Random;

/**
 * Desktop test for the detector + controller. Simulates a Fisch-style reel (hold = bar accelerates
 * right, release = bar falls left, fish wanders), draws each frame as pixels, runs the real
 * Detector and Controller on those pixels, and reports how often the fish stayed inside the bar.
 *
 * This checks the logic against a made-up physics model. It is NOT the real game.
 *
 * Run:  javac -d out app/src/main/java/com/fischmacro/*.java tools/SimTest.java  (skip the Android files)
 *       java -cp out SimTest
 */
public class SimTest {

    static final int W = 600, H = 10;
    static final int BAR = 0xF5F5F5, FISH = 0x5AC8FF, TRACK = 0x141414;

    static double KP=0.8,KI=0.2,KD=0.2; static int PERIOD=80;

    static double run(double barW, double aggression, long seed, boolean similarColors,
                      double accel, double grav, double fishSpeedMul, double latencyMs, StringBuilder log) {
        Random rnd = new Random(seed);
        Detector det = new Detector();
        Detector.Result res = new Detector.Result();
        RodProfile prof = RodProfile.ALL[1];
        Controller ctl = new Controller(prof);
        ctl.sens = aggression;
        ctl.kpBase = KP; ctl.kiBase = KI; ctl.kdBase = KD; ctl.periodMs = PERIOD;

        final double simDt = 1.0 / 240.0;
        final double frameDt = 1.0 / 30.0;
        final int latencySteps = (int) Math.round(latencyMs / 1000.0 / simDt);
        boolean[] holdQ = new boolean[latencySteps + 1];
        int qi = 0;

        double barX = 0.3, barV = 0;
        double fish = 0.5, fishTarget = 0.5, fishSpeed = 0.6, nextPick = 0;
        double t = 0;
        double inBar = 0, total = 0;
        int[] px = new int[W * H];
        boolean held = false;
        double nextFrame = 0;
        int fishRgb = similarColors ? BAR : FISH;

        for (int step = 0; step < 240 * 60; step++) {
            t = step * simDt;
            // fish wanders
            if (t >= nextPick) {
                fishTarget = 0.04 + rnd.nextDouble() * 0.92;
                fishSpeed = (0.35 + rnd.nextDouble() * 0.9) * fishSpeedMul;
                nextPick = t + 0.4 + rnd.nextDouble() * 1.1;
            }
            double dir = Math.signum(fishTarget - fish);
            double move = Math.min(Math.abs(fishTarget - fish), fishSpeed * simDt);
            fish += dir * move;

            // bar physics (held state arrives after input latency)
            boolean effHeld = holdQ[qi % holdQ.length];
            double acc = effHeld ? accel : -grav;
            barV += acc * simDt;
            barV *= (1 - 1.2 * simDt);
            if (barV > 1.5) barV = 1.5;
            if (barV < -1.5) barV = -1.5;
            barX += barV * simDt;
            if (barX < 0) { barX = 0; if (barV < 0) barV = 0; }
            if (barX > 1 - barW) { barX = 1 - barW; if (barV > 0) barV = 0; }

            total++;
            if (fish >= barX && fish <= barX + barW) inBar++;

            // frame capture + control at 30 fps
            if (t >= nextFrame) {
                nextFrame += frameDt;
                for (int i = 0; i < px.length; i++) px[i] = TRACK;
                int bl = (int) Math.round(barX * W), br = (int) Math.round((barX + barW) * W);
                int fl = (int) Math.round(fish * W) - 12, fr = fl + 24;
                for (int y = 0; y < H; y++) {
                    for (int x = Math.max(0, bl); x < Math.min(W, br); x++) px[y * W + x] = BAR;
                    for (int x = Math.max(0, fl); x < Math.min(W, fr); x++) px[y * W + x] = fishRgb;
                }
                for (int i = 0; i < px.length; i++) {
                    int p = px[i];
                    int n = rnd.nextInt(17) - 8;
                    int r = clamp(((p >> 16) & 255) + n), g = clamp(((p >> 8) & 255) + n), b = clamp((p & 255) + n);
                    px[i] = (r << 16) | (g << 8) | b;
                }
                det.detect(px, W, H, BAR, fishRgb, 70, res);
                long tNs = (long) (t * 1e9);
                ctl.update(res, tNs);
                if (log != null && step % (240 * 5) < 8 && log.length() < 4000) {
                    log.append(String.format("t=%.1f barL=%.3f(det %.3f) fish=%.3f(det %.3f) ok=%b duty=%.2f%n",
                            t, barX, res.barL / W, fish, res.fishX / W, res.ok(), ctl.duty()));
                }
            }
            held = ctl.wantHold((long) (t * 1e9));
            qi++;
            holdQ[qi % holdQ.length] = held;
        }
        return inBar / total;
    }

    static void sweep() {
        double[] kps = {0.4, 0.55, 0.8, 1.1};
        double[] kds = {0.03, 0.07, 0.12, 0.2};
        double[] kis = {0.2, 0.35, 0.6};
        int[] periods = {70, 100, 140};
        double bestScore = 0; String bestCfg = "";
        for (int per : periods) for (double kp : kps) for (double kd : kds) for (double ki : kis) {
            KP = kp; KD = kd; KI = ki; PERIOD = per;
            double sum = 0; int n = 0;
            for (double bw : new double[] {0.12, 0.18, 0.30}) for (long s = 1; s <= 3; s++) {
                sum += run(bw, 1.0, s, false, 5.0, 4.0, 1.0, 60, null);
                sum += run(bw, 1.0, s + 10, false, 6.0, 6.0, 1.6, 100, null);
                n += 2;
            }
            double sc = sum / n;
            if (sc > bestScore) { bestScore = sc; bestCfg = "kp=" + kp + " ki=" + ki + " kd=" + kd + " period=" + per; }
        }
        System.out.printf("best avg %.1f%% with %s%n", bestScore * 100, bestCfg);
    }

    static int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("sweep")) { sweep(); return; }
        double[] widths = {0.12, 0.18, 0.25, 0.30, 0.40};
        System.out.println("Fish-in-bar % over 60 s, 5 seeds, distinct fish color, 60 ms input lag");
        for (double bw : widths) {
            double sum = 0, min = 1;
            for (long s = 1; s <= 5; s++) {
                double v = run(bw, 1.0, s, false, 5.0, 4.0, 1.0, 60, null);
                sum += v;
                min = Math.min(min, v);
            }
            System.out.printf("  bar %.2f of track: avg %.0f%%  worst %.0f%%%n", bw, sum / 5 * 100, min * 100);
        }
        System.out.println("Same but fish and bar the SAME color (shape-only detection)");
        for (double bw : widths) {
            double sum = 0;
            for (long s = 1; s <= 5; s++) sum += run(bw, 1.0, s, true, 5.0, 4.0, 1.0, 60, null);
            System.out.printf("  bar %.2f of track: avg %.0f%%%n", bw, sum / 5 * 100);
        }
        System.out.println("Harder physics: faster fish (x1.6), stronger gravity, 100 ms lag");
        for (double bw : widths) {
            double sum = 0;
            for (long s = 1; s <= 5; s++) sum += run(bw, 1.0, s, false, 6.0, 6.0, 1.6, 100, null);
            System.out.printf("  bar %.2f of track: avg %.0f%%%n", bw, sum / 5 * 100);
        }
        System.out.println("Sensitivity sweep at bar 0.18 (distinct color, default physics)");
        for (double sens : new double[] {0.5, 0.75, 1.0, 1.5, 2.0}) {
            double sum = 0;
            for (long s = 1; s <= 5; s++) sum += run(0.18, sens, s, false, 5.0, 4.0, 1.0, 60, null);
            System.out.printf("  sens %.2f: avg %.0f%%%n", sens, sum / 5 * 100);
        }
        StringBuilder log = new StringBuilder();
        run(0.18, 1.0, 1, false, 5.0, 4.0, 1.0, 60, log);
        System.out.println("Sample trace:\n" + log);
    }
}
